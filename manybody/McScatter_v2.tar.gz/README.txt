>  Reader for McScatter

   Educational program for integrating SeBa binary evolution with simple stellar dynamics. The dynamics is based on binary scattering in a multi-mass field of stars with uniform density and velocity dispersion, using the scattering cross section of Giersz (MNRAS, 2001, 324, 218-30). Exchanges are not allowed at present. 

 download entire source code of  McScatter.tar.gz 

 McScatter.tar.gz contains the following files: 
   README   This file 
   Makefile   Makefile (based on starlab distribution 4.1.1 or earlier) 
   McScatter.f Monte-Carlo driver for performing scattering
   experiments between a (pre-determined) binary and a population of 
   single star (selected randomly from an IMF). includes binary
   evolution from SeBa (Portegies Zwart & Verbunt, 1996, A&A 309,
   179).
   evolveSS.f   Single star evolution from SeBa without scattering. 
   evolveBS.f   Binary star evolution from SeBa without scattering. 
   interface_SeBa.h   Header file for SeBa interface.
   interface_SeBa.C   Single star and binary star evolution interface. requires starlab version 4.1.1 to compile. 
   ran2.C   Numerical Recipes (Press et al.) random number generator 
   example.in   example input file for McScatter 
   example.log   example log file for McScatter 
   example.out   example output file for McScatter 
   SeBa.data   Diagnostic output from SeBa. This file is further processed with roche. The output if this exercise is listen in the table below (roche.log, SeBa_xxxx.gif and SeBa_xxxx.txt). 
   binev.data   Diagnostic output from SeBa. 
   McScatter.txt   Text version of manybody.org/McScatter html page. 

   Typical command line (generates : McScatter.out and McScatter.log) 
 % (McScatter < McScatter.in > McScatter.out )>& McScatter.log 
 
 Further processing of the data file SeBa.data. Typical command line (generates : roche.log, SeBa_xxxx.gif and SeBa_xxxx.txt)
 % (roche < SeBa.data > )>& roche.log 
 
 
 roche.log   log file from roche.
   SeBa_0001.gif   Output gif file from roche, representing an image of the binary system. Subsequent files (SeBa_0003.gif, SeBa_0004.gif, SeBa_0006.gif---SeBa_0009.gif and SeBa_0011.gif---SeBa_0014.gif) show later evolutionary stages of the same binary. 
   SeBa_0002.txt   Output text file from roche, summarizes the scattering encounters experienced by the binary. Subsequent files (SeBa_0005.txt and SeBa_0010.txt) contain information about subsequent McScatter events. 

   
 For more information see: http://www.manybody.org 
 
 
 25 February 2003
 Douglas C. Heggie
 Simon F. Portegies Zwart
 
 Version log:
 Version 1.1: Extended for use with roche by SPZ on 23 April 2003
