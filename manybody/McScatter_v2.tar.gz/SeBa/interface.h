#include <vector>
#include "dyn.h" 
#include "scatter3.h"
#include "double_star.h"
#include "main_sequence.h"
#include "constants.h"

#include "SeBa_tt.h"

#ifndef   _INTERFACE_SEBA
#define   _INTERFACE_SEBA

#ifndef EPSILON
  #define EPSILON 1.e-10
#endif

#define CHK_SEMI_LIMIT 0.05
#define CHK_MASS_LIMIT 0.05
#define CHK_ECC_LIMIT 0.05
#define CHK_SIZE_LIMIT 1

static 
class interface_SeBa {
 protected:
  dyn * root;
  dyn * root_star;

  vector<dyn*> binarray;
  vector<dyn*> sinarray;

 private:

  dyn* mkbinary(int n);
  void add_secondary(dyn* original, real mass_ratio);

 public:

  interface_SeBa() {
    root = NULL;
    root_star = NULL; 
  }

  ~interface_SeBa() {
    if(root) delete root;
    if(root_star) delete root_star;
    //    if(binarray) delete[] binarray;
    //    if(sinarray) delete[] sinarray;
  }

  dyn* get_root() {return root;}

  dyn* get_binary(int id);
  dyn* get_star(int id);
  void construct_star(dyn *bi, real mass);
  void create_stars(int *n, int id[], real mass[]);
  void create_binaries(int n, int id[]);
  void initialize_primaries(int id[], real mass[]);
  void initialize_secondaries(int id[], real mass[]);
  bool evolve_binary(dyn * bi,
		     real start_time, real end_time,
		     bool stop_at_merger_or_disruption,
		     bool stop_at_remnant_formation);
  void evolve_star_until_next_time(node* bi, const real out_time);
  void report_strong_encounter(double_star *ds, single_star *ss, 
			       real time, char *filename);

  final_descriptor3 exchange_id_to_mass(int outcome);
  void create_search_array_for_stars();
  void create_search_array_for_binaries();

  star *get_loid_star();
  star *get_hiid_star();

} interface;


extern "C"
void init_stars__(int *n, int id[], real mass[]);
extern "C"
void init_binaries__(int *n, int id[], 
		    real sma[], real ecc[], real mprim[], real msec[]);
extern "C"
void ev_star__(int *id, real *time);
extern "C"
void ev_stars__(int *n, int *id, real *time);
extern "C"
void ev_binary__(int *id, real *time,   
		 bool stop_at_merger_or_disruption = true,
		 bool stop_at_remnant_formation = false);
extern "C"
void ev_binaries__(int *n, int *id, real *time, 
		   bool stop_at_merger_or_disruption = true,
		   bool stop_at_remnant_formation = false);

// get/set routines
// ...

extern "C"
void get_sma__(int *id, real *sma);
extern "C"
void set_sma__(int *id, real *sma);
extern "C"
void get_ecc__(int *id, real *ecc);
extern "C"
void set_ecc__(int *id, real *ecc);

// only get_
// ...

extern "C"
void get_radius__(int *id, real *radius);
extern "C"
void get_mass__(int *id, real *mass);
extern "C"
void get_loid__(int *id, int *loid);
extern "C"
void get_hiid__(int *id, int *hiid);
extern "C"
void get_loid_mass__(int *id, real *mass);
extern "C"
void get_hiid_mass__(int *id, real *mass);
extern "C"
void get_ss_type__(int *id, int *type);
extern "C"
void get_bs_type__(int *id, int *type);
extern "C"
void get_ss_updatetime__(int *id, real *update_time);
extern "C"
void get_bs_updatetime__(int *id, real *update_time);

// in-/out put routines
// ...

extern "C"
void out_star__(int *id);
extern "C"
void out_binary__(int *id);
extern "C"
void out_scatter__(int *idb, int *idt, real *time, bool *write_text);

// miscellaneous routines
// ...

extern "C"
void binary_exists__(int *id, int *exit);
extern "C"
void morph_binary__(int *idb, int *idt, real *a_factor, real *e, int *outcome);










 







#endif //  _INTERFACE_SEBA

