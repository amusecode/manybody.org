#include "interface.h"

// initialization routines:
// ...

void init_stars__(int *n, int id[], real mass[]) {

  interface.create_stars(n, id, mass);
  interface.create_search_array_for_stars();

}

// local for now.
local void init_binary__(int *pid, 
			 real *psma, real *pecc, real *pmprim, real *pmsec) 
{

  int id = *pid;
  real sma = *psma;
  real ecc = *pecc;
  real mprim = *pmprim;
  real msec = *pmsec;
  interface.initialize_primaries(pid, pmprim);
  interface.initialize_secondaries(pid, pmsec);

  //  put_dyn(cerr, *root);

  real mass_scale = mprim+msec;
  real size_scale = 1;
  real time_scale = 1;
  interface.get_root()->get_starbase()
                      ->set_stellar_evolution_scaling(mass_scale,
						      size_scale,
						      time_scale);

  int i=0;
  real time = 0;
  binary_type bin_type = Detached;
  bool stop_at_merger_or_disruption = true;
  bool stop_at_remnant_formation = false;
  for_all_daughters(dyn, interface.get_root(), bi) {
    if(bi->get_index()==id) {

      double_star *ds = new_double_star(bi, sma, ecc, time, 
			   id, bin_type);

      ds->set_use_hdyn(false);
      ds->get_primary()->set_identity(0);
      ds->get_secondary()->set_identity(1);

      interface.evolve_binary(bi, time, time, 
		    stop_at_merger_or_disruption, stop_at_remnant_formation);
      
      //      ds->dump("SeBa.data", true);
    }
  }
}

void init_binaries__(int *n, int id[], 
		real sma[], real ecc[], real mprim[], real msec[]) 
{

  interface.create_binaries(*n, id);
  interface.create_search_array_for_binaries();

  for(int i=0; i<*n; i++) {
    init_binary__(&id[i], &sma[i], &ecc[i], &mprim[i], &msec[i]);
  }

}

// evolution routines
// ...

void ev_star__(int *id, real *time) {

  dyn *si = interface.get_star(*id);
  interface.evolve_star_until_next_time(si, *time);
}

void ev_stars__(int *n, int *id, real *time)
{

  for(int i=0; i<*n; i++) {
    ev_star__(&id[i], &time[i]);
  }

}

void ev_binary__(int *id, real *time,   
		 bool stop_at_merger_or_disruption, 
		 bool stop_at_remnant_formation)
{

  dyn *bi = interface.get_binary(id[0]);
  interface.evolve_binary(bi, *time, *time, 
			  stop_at_merger_or_disruption, 
			  stop_at_remnant_formation);

}

void ev_binaries__(int *n, int *id, real *time,   
		   bool stop_at_merger_or_disruption, 
		   bool stop_at_remnant_formation)

{

  for(int i=0; i<*n; i++) 
    ev_binary__(&id[i], &time[i],   
		stop_at_merger_or_disruption, 
		stop_at_remnant_formation);
}

// get/set_ routines
// ...

void get_sma__(int *id, real *sma) {

  dyn *bi = interface.get_binary(*id);

  if(bi!=NULL) {
    *sma = ((double_star*)bi->get_starbase())->get_semi();
  }
}

void set_sma__(int *id, real *sma) {

  dyn *bi = interface.get_binary(*id);

  if(bi!=NULL) {
      ((double_star*)bi->get_starbase())->set_semi(*sma);
  }
}

void get_ecc__(int *id, real *ecc) {

  dyn *bi = interface.get_binary(*id);

  if(bi!=NULL) {
    *ecc = ((double_star*)bi->get_starbase())->get_eccentricity();
  }
}

void set_ecc__(int *id, real *ecc) {

  dyn *bi = interface.get_binary(*id);

  if(bi!=NULL) {
      ((double_star*)bi->get_starbase())->set_eccentricity(*ecc);
  }
}

// only get_ routines
// ...

void get_radius__(int *id, real *radius) {

  dyn *si = interface.get_star(*id);
  *radius = ((single_star*)si->get_starbase())->get_effective_radius();
}

void get_mass__(int *id, real *mass) {

  dyn *si = interface.get_star(*id);
  *mass = ((single_star*)si->get_starbase())->get_total_mass();
}

void get_loid__(int *id, int *loid) {

  *loid = interface.get_loid_star()->get_identity();
}

void get_hiid__(int *id, int *hiid) {

  *hiid = interface.get_hiid_star()->get_identity();
}

void get_loid_mass__(int *id, real *mass) {

  *mass = interface.get_loid_star()->get_total_mass();
}

void get_hiid_mass__(int *id, real *mass) {

 *mass = interface.get_hiid_star()->get_total_mass();
}

void get_ss_type__(int *id, int *type)
{
  dyn *si = interface.get_star(*id);
  *type = (int)si->get_starbase()->get_element_type();
}

void get_bs_type__(int *id, int *type)
{
  dyn *bi = interface.get_binary(*id);
  *type = (int)bi->get_starbase()->get_element_type();
}

void get_ss_updatetime__(int *id, real *update_time) 
{
 
 dyn *si = interface.get_star(*id);
 *update_time = ((single_star*)si->get_starbase())->get_next_update_age();

}

void get_bs_updatetime__(int *id, real *update_time) 
{
 
 dyn *bi = interface.get_binary(*id);
 real dt = ((double_star*)bi->get_starbase())->get_evolve_timestep();

 *update_time = dt+cnsts.safety(minimum_timestep); //+ct+

}

// I/O routines
// ...

void out_star__(int *id)
{
  
  stellar_type type = NAS;
  dyn *si = interface.get_star(*id);
  type = si->get_starbase()->get_element_type();
  real mass = si->get_starbase()->get_total_mass();
  real radius = si->get_starbase()->get_effective_radius();
  cout << type_string(type) << " (" << type << "), ";

}
void out_binary__(int *id)
{

  dyn *bi = interface.get_binary(*id);
  ((double_star*)bi->get_starbase())->print_status();

}

void out_scatter__(int *idb, int *idt, real *time,
		      bool *write_text)
{

  dyn *bi = interface.get_binary(*idb);
  double_star * ds = ((double_star*)bi->get_starbase());
  if(!(*write_text))
    ds->dump("SeBa.data", true);

  if(*write_text) {
    dyn *si = interface.get_star(*idt);
    single_star * ss = ((single_star*)si->get_starbase());

    interface.report_strong_encounter(ds, ss, *time, "SeBa.data"); //, *write_text);
  }
}


// other routines
// ...

void binary_exists__(int *id, int *exit) {

  dyn *bi = interface.get_binary(*id);

  *exit = 1;   // binary alive/in leven
  if(((double_star*)bi->get_starbase())->get_bin_type() == Merged || 
     ((double_star*)bi->get_starbase())->get_bin_type() == Disrupted)
    {
      *exit = 0;
    }
}

void synchronize_all_stars(dyn *bi, dyn *si) {

  //  cerr << "synchronize_all_stars(dyn *bi, dyn *si)" << endl;

  if(si==NULL || bi==NULL) 
    return;

  double_star* ds = dynamic_cast(double_star*, bi->get_starbase());
  single_star* ss = dynamic_cast(single_star*, si->get_starbase());

  real ts = ss->get_current_time();
  real td = ds->get_current_time();

  if(ts>td) {
    ds->evolve_element(ts);

    // synchronize dynamics
    double_star* ds = dynamic_cast(double_star*, bi->get_starbase());
    real mp = ds->get_primary()->get_total_mass();
    real ms = ds->get_secondary()->get_total_mass();
    ds->get_primary()->get_node()->set_mass(mp);
    ds->get_secondary()->get_node()->set_mass(ms);
  }
}

void morph_binary__(int *idb, int *idt, real *a_factor, real *e, int *outcome) {
  dyn *bi = interface.get_binary(*idb);
  if(outcome == 0 &&                            // meaning preservation
     *a_factor == 1 &&                          // no change in semi-major axis
     *e == ((starbase*)bi)->get_eccentricity()) // same ecc as before
    return;
  
  initial_state3 init3;
  intermediate_state3 inter3;
  final_state3 final3;

  // final3.sma multiplies internally in SeBa_tt.C
  //   with the binary orbital separation.
  //   Reason is that final3 structure is also used for normalized N-body units
  final3.sma = *a_factor;
  final3.ecc = *e;
  final3.descriptor = interface.exchange_id_to_mass(*outcome);

  dyn *si = NULL;
  if(*outcome>0) { // if non-preservation
    si = interface.get_star(*idt);
    //    PRC(final3.descriptor);PRL(((star*)si->get_starbase())->get_identity());
    //    si->get_starbase()->dump(cerr, false);
  }

  synchronize_all_stars(bi, si);

  /*
  star *ps = ((star*)bi->get_starbase())->get_primary();
  star *ss = ps->get_companion();
  ps->get_node()->set_mass(ps->get_total_mass());
  ss->get_node()->set_mass(ss->get_total_mass());
  */

  final_descriptor3 fate = form_scatter_product(bi, si, init3, inter3, final3);

  if(*outcome>0) { 
    bi->get_starbase()->dump(cerr, false);
  }
}
