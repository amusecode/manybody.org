#include "interface.h"

#define MINIMUM_EVOLUTION_TIME_STEP_FRACTION 0.1

dyn* interface_SeBa::get_binary(int id) {

  dyn *bin = NULL;
  bin = binarray[id];

  if(bin==NULL) {
    cerr << "No binary found in *get_binary(int id=" << id << ")" << endl;
    exit(-1);
  }

  return bin;
#if 0
  dyn *bin = NULL;
  for_all_daughters(dyn, root, bi) {
    if(bi->get_index()==id) {
      bin = bi;
      break;
    }
  }

  return bin;
#endif
}

dyn* interface_SeBa::get_star(int id) {

  dyn *sin = NULL;

  sin = sinarray[id];

  if(sin==NULL) {
    cerr << "No star found in *get_star(int id=" << id << ")" << endl;
    exit(-1);
  }

  return sin;
}

void interface_SeBa::construct_star(dyn *bi, real mass) 
{
  stellar_type type = Main_Sequence;
  real t_cur, t_rel, m_rel, m_tot, m_core, mco_core, p_rot, b_fld;
  t_cur=t_rel=mco_core=p_rot=b_fld = 0;

  m_rel = mass;
  if(mass>0.01) {
    m_tot = mass;
    m_core = 0.01*mass;
  }
  else {
    m_core = 0.01*mass;
    m_tot = mass;
  }

  int id = bi->get_index();
  //ignore return value
  single_star* new_star = new_single_star(type, id,
					  t_cur, t_rel,
					  m_rel, m_tot, m_core,
					  mco_core,
					  p_rot, b_fld, bi);

}

void interface_SeBa::create_stars(int *n, int id[], real mass[]) {

  //  int nn = *n;
  if(root_star!=NULL) {
    delete root_star;
    root_star = NULL;
  }

  //  if(root_star==NULL) {
    root_star = mkdyn(*n);
    root_star->get_starbase()->set_stellar_evolution_scaling(1., 1., 1.);
    //    root_star->get_starbase()->set_use_hdyn(false);

    //    for(int i=0; i<*n; i++) {
    int i=0;
    for_all_daughters(dyn, root_star, bi) {
      bi->set_index(id[i]);
      bi->set_mass(mass[i]);
      i++;
      //      root_star->set_mass(mass[i]);
    }
    //    PRC(root_star->get_mass());
    //    PRL(mass[0]);

    //  }

  real time = 0;
  stellar_type type = Main_Sequence;
  addstar(root_star, time, type);
  root_star->get_starbase()->set_use_hdyn(false);

  //  put_dyn(cerr, *root_star);
}

void interface_SeBa::create_binaries(int n, int id[]) {

  if(root==NULL) {
    root = mkbinary(n);
  }
  
  char tmp[128];
  int i=0;
  dyn *p, *s;
  for_all_daughters(dyn, root, bi) {
    bi->set_index(id[i]);
    p = bi->get_oldest_daughter();
    s = p->get_younger_sister();

    sprintf(tmp, "%d", bi->get_index());
    bi->set_name(tmp);
    p->set_name(bi->get_name());
    s->set_name(bi->get_name());
    strcat(p->get_name(), "a");
    strcat(s->get_name(), "b");

    i++;
  }
}

void interface_SeBa::initialize_primaries(int id[], real mass[])
{

  int i =0;
  dyn *p;
  for_all_daughters(dyn, root, bi) {
    if(bi->get_index()==id[i]) {
      p = bi->get_oldest_daughter();
      p->set_mass(mass[i]);
      construct_star(p, mass[i]);
      i++;
    }
  }
}

void interface_SeBa::initialize_secondaries(int id[], real mass[])
{

  int i =0;
  dyn *s;
  for_all_daughters(dyn, root, bi) {
    if(bi->get_index()==id[i]) {
      s = bi->get_oldest_daughter()->get_younger_sister();
      s->set_mass(mass[i]);
      construct_star(s, mass[i]);
      i++;
    }
  }
}

bool  interface_SeBa::evolve_binary(dyn * bi,
                          real start_time, real end_time,
			  bool stop_at_merger_or_disruption,
			  bool stop_at_remnant_formation) { 

  double_star* ds = dynamic_cast(double_star*, 
				 bi->get_starbase());
  
  real bin_age = ds->get_current_time();

  if((end_time-bin_age)/bin_age<MINIMUM_EVOLUTION_TIME_STEP_FRACTION) {
    return false;
  }
  //  cerr << "Evolve at t= " << bin_age << " " << end_time << endl;

  real a = ds->get_semi();
  real e = ds->get_eccentricity();
  real tpp = ds->get_primary()->get_element_type();
  real mp = ds->get_primary()->get_total_mass();
  real rp = ds->get_primary()->get_effective_radius();
  real tps = ds->get_secondary()->get_element_type();
  real ms = ds->get_secondary()->get_total_mass();
  real rs = ds->get_secondary()->get_effective_radius();

  //  ds->dump(cerr, false);
  //		Setup star from input data.
  real dt, time=start_time;
  ds->evolve_element(time);
  
  //  ds->dump("SeBa.data", true);

  if (!bi->is_root() &&
      bi->get_parent()->is_root()) 

    do {

      dt = ds->get_evolve_timestep() + cnsts.safety(minimum_timestep);
      time = Starlab::min(time+dt, end_time);

      ds->evolve_element(time);

      if (stop_at_merger_or_disruption &&
	  (ds->get_bin_type() == Merged || 
	   ds->get_bin_type() == Disrupted))
	return false;

      if (stop_at_remnant_formation &&
	 (ds->get_primary()->remnant() || ds->get_secondary()->remnant()))
	return false;

    }
    while (time<end_time);

  //  ds->dump("SeBa.data", true);

  star *ps = ds->get_primary();
  star *ss = ds->get_secondary();
  real a1 = ds->get_semi();
  real e1 = ds->get_eccentricity();
  real tpp1 = ps->get_element_type();
  real mp1 = ps->get_total_mass();
  real rp1 = ps->get_effective_radius();
  real tps1 = ss->get_element_type();
  real ms1 = ss->get_total_mass();
  real rs1 = ss->get_effective_radius();

  ps->get_node()->set_mass(mp1);
  ss->get_node()->set_mass(ms1);

  real da = abs((a1-a)/a);
  real de = abs(e1-e);
  real dmp = abs((mp1-mp)/mp);
  real dms = abs((ms1-ms)/ms);
  real drp = abs((rp1-rp)/rp);
  real drs = abs((rs1-rs)/rs);
  //  PRC(da);PRC(de);PRC(dmp);PRC(dms);PRC(drp);PRL(drs);
  //  PRC(tps);PRC(tps1);PRC(tpp);PRL(tpp1); 
  if(da>CHK_SEMI_LIMIT||
     de>CHK_ECC_LIMIT||
     dmp>CHK_MASS_LIMIT||dms>CHK_MASS_LIMIT||
     drp>CHK_SIZE_LIMIT||drs>CHK_SIZE_LIMIT||
     tpp!=tpp1||tps!=tps1)
    ds->print_status();
    
  return true;

}

void interface_SeBa::evolve_star_until_next_time(node* bi, const real out_time) {

          real current_time = ((star*)bi->get_starbase())->get_current_time();
          real time_step    =  bi->get_starbase()->get_evolve_timestep();

          while (out_time>current_time+time_step) {
             bi->get_starbase()->evolve_element(current_time+time_step);
             bi->get_starbase()->evolve_element(
                 Starlab::min(current_time+time_step+EPSILON, out_time));
             current_time = ((star*)bi->get_starbase())->get_current_time();
             time_step    =  bi->get_starbase()->get_evolve_timestep();

	     //	     star_state ss(dynamic_cast(star*, bi->get_starbase()));
	     //	     put_state(ss, cerr);

	     // print_star(bi->get_starbase(), cerr);

	     //	     int p = cerr.precision(HIGH_PRECISION);
	     //	     bi->get_starbase()->dump(cerr, false);
	     //	     cerr.precision(p);
          }
         bi->get_starbase()->evolve_element(out_time);

	 //         print_star(bi->get_starbase(), cerr);

/*
cerr<< "ov: " << bi->get_starbase()->get_element_type() 
        << " " <<bi->get_starbase()->get_total_mass() << " t= "
        << ((star*)bi->get_starbase())->get_current_time() << " "
        << ((star*)bi->get_starbase())->get_current_time()
           +bi->get_starbase()->get_evolve_timestep() << " -> "
        << out_time << endl;
*/
}

void interface_SeBa::report_strong_encounter(double_star *ds, single_star *ss, 
				   real time, char *filename) {
		   //				   bool write_text) {

  ofstream s(filename, ios::app|ios::out);
  if(!s) cerr << "Error: couldn't create file " << filename << endl;

  int id1 = ds->get_primary()->get_identity();
  stellar_type st1 = ds->get_primary()->get_element_type();
  real m1 = ds->get_primary()->get_total_mass();
  real r1 = ds->get_primary()->get_effective_radius();

  int id2 = ds->get_secondary()->get_identity();
  stellar_type st2 = ds->get_secondary()->get_element_type();
  real m2 = ds->get_secondary()->get_total_mass();
  real r2 = ds->get_secondary()->get_effective_radius();

  int id3 = ss->get_identity();
  stellar_type st3 = ss->get_element_type();
  real m3 = ss->get_total_mass();
  real r3 = ss->get_effective_radius();

  int identity = ds->get_identity();
  binary_type bin_type = Strong_Encounter;
  //  if(!write_text)
  //    bin_type = Detached; //ds->get_bin_type();
  mass_transfer_type current_mass_transfer_type = Unknown;
  real binary_age = ds->get_current_time();
  real semi = ds->get_semi();
  real eccentricity = ds->get_eccentricity();

    s << identity << " "
      << bin_type << " "
      << current_mass_transfer_type << " "
      << binary_age << " "
      << semi << " "
      << eccentricity << "     ";

    s << id1 << " " << st1 << " " << m1 << " " << r1 << " "; 
    s << id2 << " " << st2 << " " << m2 << " " << r2 << " "; 
    s << id3 << " " << st3 << " " << m3 << " " << r3;

    s << endl;

    s.close();
#if 0
    s << identity << " "
      << bin_type << " "
      << current_mass_transfer_type << " "
      << binary_age << " "
      << semi << " "
      << eccentricity << "     ";

	s << stp->get_identity() << " "	  
	  << stp->get_element_type() << " "
	  << m1 << " "
	  << stp->get_effective_radius() << " "
	  << log10(stp->temperature()) << " "
	  << stp->get_core_mass() << "    "
	  //      << stp->get_effective_radius()/primary_roche_lobe  << "    "

	  << sts->get_identity() << " "	  
	  << sts->get_element_type() << " "
	  << m2 << " "
	  << sts->get_effective_radius() << " "
	  << log10(sts->temperature()) << " "
	  << sts->get_core_mass() 
	  //      << sts->get_effective_radius()/secondary_roche_lobe
	  << endl;
#endif
}

final_descriptor3 interface_SeBa::exchange_id_to_mass(int outcome) {

  if(outcome<=0)
    return preservation;

  star * lo = get_loid_star();
  star * hi = get_hiid_star();

#if 0
  if(outcome==2) 
    cerr << "Exchange low-id star" << endl;
  else
    cerr << "Exchange high-id star" << endl;

  PRC(outcome);PRC(lo->get_identity());PRL(hi->get_identity());
#endif

  bool lowid_is_primary = false;
  if(lo->get_total_mass() > hi->get_total_mass()) {
    lowid_is_primary = true;
  }

  final_descriptor3 descriptor;
  //  if(lo->get_total_mass() > hi->get_total_mass())
  if(lowid_is_primary) {
    if(outcome==1)
      descriptor = exchange_2;
    else if(outcome==2)
      descriptor = exchange_1;
    else {
      cerr << "Unknown descriptor in final_descriptor3 interface_SeBa::exchange_id_to_mass(int outcome= " << outcome << ");" << endl;
      exit (-1);
    }
  }
  else {
    if(outcome==1)
      descriptor = exchange_1;
    else if(outcome==2)
      descriptor = exchange_2;
    else {
      cerr << "Unknown descriptor in final_descriptor3 interface_SeBa::exchange_id_to_mass(int outcome= " << outcome << ");" << endl;
      exit (-1);
    }
  }

  return descriptor;
}

void interface_SeBa::create_search_array_for_stars() {

  int n = 0;
  for_all_daughters(dyn, root_star, si) {
    int ns = sinarray.size();
    int ni = si->get_index();
    int di = si->get_index() - ns;
    if(di>0) {
      //      fill_n(sinarray.end(), di, NULL);
      for(int i=ns; i<ni; i++) {
	sinarray.push_back(NULL);
      }
    }
    ns = sinarray.size();
    if(ni==ns) {
      sinarray.push_back(si);
    }
  }
}

void interface_SeBa::create_search_array_for_binaries() {

  int n = 0;
  for_all_daughters(dyn, root, si) {
    int ns = binarray.size();
    int ni = si->get_index();
    int di = si->get_index() - ns;
    if(di>0) {
      for(int i=ns; i<ni; i++) {
	binarray.push_back(NULL);
      }
    }
    ns = binarray.size();
    if(ni==ns) {
      binarray.push_back(si);
    }
  }
}

star* interface_SeBa::get_loid_star() {

  star * loid; 
  dyn * ds_node = root->get_oldest_daughter();
  double_star *ds = (double_star*)ds_node->get_starbase();
  star *ps = ds->get_primary();
  star *ss = ds->get_secondary();
  if(ps->get_identity()<ss->get_identity())
    loid = ps;
  else
    loid = ss;
    
  return loid;
}

star* interface_SeBa::get_hiid_star() {

  star * hiid; 
  dyn * ds_node = root->get_oldest_daughter();
  double_star *ds = (double_star*)ds_node->get_starbase();
  star *ps = ds->get_primary();
  star *ss = ds->get_secondary();
  if(ss->get_identity()>ps->get_identity())
    hiid = ss;
  else
    hiid = ps;
    
  return hiid;
}

void interface_SeBa::add_secondary(dyn* original, real mass_ratio) {

    dyn* primary = new dyn;
    dyn* secondary = new dyn;

    original->set_oldest_daughter(primary);

    primary->set_parent(original);
    secondary->set_parent(original);

    primary->set_younger_sister(secondary);
    secondary->set_elder_sister(primary);

    // Set new masses.

    primary->set_mass(original->get_mass());
    secondary->set_mass(mass_ratio*original->get_mass());
    original->inc_mass(secondary->get_mass());

	if (original->get_name() == NULL) {

	    // Make a name for use by the components.

	    char tmp[128];
	    if (original->get_index() >= 0)
		sprintf(tmp, "%d", original->get_index());
	    else
		sprintf(tmp, "X");
	    original->set_name(tmp);
	}
	else {

	    // Label components "a" and "b".

	    primary->set_name(original->get_name());
	    secondary->set_name(original->get_name());
	    strcat(primary->get_name(), "a");
	    strcat(secondary->get_name(), "b");
	}

    // Make standard CM name.
}


dyn* interface_SeBa::mkbinary(int n) {

  dyn *root, *the_binary;
  root = mkdyn(1);
  root->set_mass(1);
  //  root->get_starbase()->set_use_hdyn(false);

  real q = 1;
  for (int i=0; i<n; i++) {

    the_binary = root->get_oldest_daughter();
    add_secondary(the_binary, q);
  }

  return root;
}




